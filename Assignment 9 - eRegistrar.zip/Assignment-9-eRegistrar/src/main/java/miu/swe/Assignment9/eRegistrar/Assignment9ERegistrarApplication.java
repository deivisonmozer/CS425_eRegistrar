package miu.swe.Assignment9.eRegistrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment9ERegistrarApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment9ERegistrarApplication.class, args);
	}

}
